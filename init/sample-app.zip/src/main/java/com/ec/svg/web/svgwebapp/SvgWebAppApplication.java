package com.ec.svg.web.svgwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SvgWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SvgWebAppApplication.class, args);
	}

}
