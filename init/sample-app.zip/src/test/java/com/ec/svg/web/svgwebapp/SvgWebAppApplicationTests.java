package com.ec.svg.web.svgwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SvgWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
